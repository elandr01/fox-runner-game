package javacalculus.test;

import javacalculus.core.CalculusEngine;

public abstract class BaseTest {
    protected CalculusEngine engine = new CalculusEngine();
}
